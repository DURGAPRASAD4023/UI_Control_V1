// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBJRfKXlGcDnjEiSZWmsktw6td2BYUPmlQ",
  authDomain: "ui-control-deccan-6d991.firebaseapp.com",
  projectId: "ui-control-deccan-6d991",
  storageBucket: "ui-control-deccan-6d991.firebasestorage.app",
  messagingSenderId: "966874610984",
  appId: "1:966874610984:web:5029100319a21cee49641d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);